import streamlit as st
from pipeline.pdf_reader import extract_text
from pipeline.text_splitter import split_text
from pipeline.embeddings import create_vector_store
from pipeline.search import search_query
import os

st.set_page_config(page_title="Enterprise PDF Knowledge Search", layout="wide")

st.title("📘 Enterprise PDF → Searchable Knowledge System")

uploaded_file = st.file_uploader("Upload Enterprise PDF", type=["pdf"])

if uploaded_file:
    pdf_path = f"data/uploads/{uploaded_file.name}"
    os.makedirs("data/uploads", exist_ok=True)

    with open(pdf_path, "wb") as f:
        f.write(uploaded_file.read())

    st.success("PDF Uploaded Successfully")

    with st.spinner("Extracting and Processing PDF..."):
        text = extract_text(pdf_path)
        chunks = split_text(text)
        create_vector_store(chunks)

    st.success("PDF Converted into Searchable Knowledge")

query = st.text_input("🔍 Ask your question from the document")

if query:
    results = search_query(query)
    st.subheader("📌 Relevant Information")
    for res in results:
        st.write(res)
