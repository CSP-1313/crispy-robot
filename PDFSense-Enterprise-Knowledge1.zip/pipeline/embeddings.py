from sentence_transformers import SentenceTransformer
import faiss
import os
import pickle

model = SentenceTransformer("all-MiniLM-L6-v2")

def create_vector_store(chunks):
    embeddings = model.encode(chunks)
    index = faiss.IndexFlatL2(len(embeddings[0]))
    index.add(embeddings)

    os.makedirs("vector_db", exist_ok=True)

    faiss.write_index(index, "vector_db/faiss.index")
    with open("vector_db/texts.pkl", "wb") as f:
        pickle.dump(chunks, f)
