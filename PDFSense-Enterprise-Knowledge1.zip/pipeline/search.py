import faiss
import pickle
from sentence_transformers import SentenceTransformer

model = SentenceTransformer("all-MiniLM-L6-v2")

def search_query(query, top_k=3):
    index = faiss.read_index("vector_db/faiss.index")
    with open("vector_db/texts.pkl", "rb") as f:
        texts = pickle.load(f)

    query_vec = model.encode([query])
    distances, indices = index.search(query_vec, top_k)

    return [texts[i] for i in indices[0]]
